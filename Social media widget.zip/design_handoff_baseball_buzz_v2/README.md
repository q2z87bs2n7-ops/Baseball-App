# Handoff — Baseball Buzz v2 (post-v4.28.2)

## Overview

Visual + small-functional upgrade to the **Pulse "Baseball Buzz"** side-rail
module shipped in v4.28.2 of the Baseball-App. The current module is a
correct-but-spartan list of post titles; this revision adds author avatars,
larger type, a category indicator, a hover affordance, an image-embed slot,
a simple filter chip row, and a "via Bluesky" attribution footer. The
section header's count badge is removed.

**Target repo:** `q2z87bs2n7-ops/Baseball-App`
**Baseline:** `main` at v4.28.2 (the branch
`claude/research-podcast-apis-JzN1O` has already merged this work into
main).
**New version:** bump `package.json` to **v4.29.0**.

## About the Design Files

The single file in this bundle, `buzz-v2-mock.html`, is a **design reference
rendered in HTML/React** — not production code. It loads the
`design-canvas.jsx` shell and renders seven artboards, each layering one
change on top of the v4.28.2 baseline. Your job is to apply those changes
in the **real Baseball-App codebase** following its existing patterns
(plain ES modules, the `src/pulse/baseball-buzz.js` render function, the
`styles.css` block at the existing `.buzz-*` rules).

The mock is implemented in React for layout-review convenience. The real
codebase is plain ES-module JS that returns HTML strings into
`#sideRailBuzz.innerHTML` — keep the same architecture. Do **not**
introduce React into the app to ship this work.

## Fidelity

**High-fidelity.** The mock uses the actual Pulse theme tokens
(`--p-card`, `--p-border`, `--p-muted`, `--p-accent`), the actual section
header pattern, and the actual buzz card geometry. Exact pixel values,
hex codes, and typography sizes are below — use them verbatim.

## Scope (explicit do / don't)

| Decision               | Status                                                |
|------------------------|-------------------------------------------------------|
| Avatars                | ✅ Ship — use Bluesky `author.avatar` from the feed payload |
| Larger type            | ✅ Ship — body 11.5 → 13px, meta 10.5 → 12px           |
| Tag → neutral pill     | ✅ Ship                                                |
| Category color dot     | ✅ Ship                                                |
| Hover ↗ glyph          | ✅ Ship                                                |
| Filter chips           | ✅ Ship (All / My team / Insiders)                     |
| Image embed            | ✅ Ship — only when post carries an image; clamp drops to 2 lines |
| "via Bluesky" footer   | ✅ Ship                                                |
| **Drop count badge**   | ✅ Ship — header always read "10"; redundant. Remove `.game-count` span from the buzz header. |
| **Placement**          | ❌ **Do not change.** Leave Buzz **below** the games list (the order shipped in v4.28.2: News → Games → Buzz). |

## Files to change

1. **`src/pulse/baseball-buzz.js`** — render logic + filter state.
2. **`src/config/buzz.js`** — add a `category` field per account.
3. **`styles.css`** — replace the existing `.buzz-*` rule block (around
   line 5095 in v4.28.2) and the `.game-count` reference in the buzz
   header.
4. **`package.json`** — bump `version` to `4.29.0`. The build pipeline
   (`build.mjs`) propagates this to `sw.js` CACHE and the `?v=` query
   strings in `index.html`. **Do not bump those manually** — per CLAUDE.md
   rule #7.
5. **`CHANGELOG.md`** + **`CLAUDE.md`** — add an entry under v4.29 (see
   "Acceptance criteria" below for the suggested phrasing).

No HTML changes — the `#sideRailBuzz` mount node stays as-is.

---

## Detailed spec

### 1. Section header

Replace the existing header with one that has no count badge:

```html
<div class="side-rail-section-header">
  <span class="side-rail-section-title">Baseball Buzz</span>
</div>
```

Remove the `count`-bearing `<span class="game-count">…</span>`. Update
`buzzHeader()` in `baseball-buzz.js` to take no argument.

### 2. Filter chip row (NEW)

A new element between the header and `.buzz-list`:

```html
<div class="buzz-filter-row" role="tablist">
  <button class="buzz-chip" data-filter="all" aria-pressed="true">All</button>
  <button class="buzz-chip" data-filter="team">My team</button>
  <button class="buzz-chip" data-filter="insider">Insiders</button>
</div>
```

- "My team" filters posts where `post.category === 'team'` **and**
  `post.tag` matches the user's selected team (see "Team-lens" below).
- "Insiders" filters `post.category === 'insider' || post.category === 'rumors'`.
- Default is "All". Active chip uses the orange accent.
- Filter state lives in module scope (`state.baseballBuzzFilter`,
  initialised to `'all'`); persisted to `localStorage` under
  `mlb_buzz_filter_v1` so it survives reload.

#### Team-lens note

The app already tracks the user's selected team — read it via the same
mechanism the rest of Pulse uses (`state.selectedTeam` or whatever the
adjacent News module reads; check `src/pulse/news-carousel.js` for the
pattern). The `tag` field on each post already carries the team name for
beat writers (e.g. "Yankees", "Astros"), so matching is a simple string
compare against the user's team display name.

If no team is selected, show the "My team" chip in a disabled state
(`opacity: 0.5; pointer-events: none`).

### 3. Buzz card layout (CHANGED)

Each card becomes a 2-column grid: avatar | content.

```html
<a class="buzz-card" href="{post.url}" target="_blank" rel="noopener noreferrer">
  <div class="buzz-row">
    <img class="buzz-avatar" src="{post.avatar}" alt="" loading="lazy"
         onerror="this.replaceWith(Object.assign(document.createElement('span'),{className:'buzz-avatar buzz-avatar-fallback',textContent:'{initials}'}))">
    <div class="buzz-body">
      <div class="buzz-meta">
        <span class="buzz-meta-name">{post.name}</span>
        <span class="buzz-tag" data-cat="{post.category}">{post.tag}</span>
        <span class="buzz-time">{relTime(post.ts)}</span>
      </div>
      <div class="buzz-text">{post.text}</div>
      {post.embedImage && <div class="buzz-embed"><img src="{post.embedImage}" alt="" loading="lazy"></div>}
    </div>
  </div>
  <span class="buzz-ext" aria-hidden="true">↗</span>
</a>
```

#### Capturing the avatar + image embed

In `fetchAccount()`, the Bluesky API already returns:

- `item.post.author.avatar` — full URL to a CDN-served thumb. Capture it.
- `item.post.embed?.images?.[0]?.thumb` — thumbnail of the first image
  embed, if present. Capture it on a new `post.embedImage` field.
- `item.post.embed?.$type === 'app.bsky.embed.images#view'` is the marker
  for an image embed; ignore `app.bsky.embed.external#view` (link previews)
  and `app.bsky.embed.record#view` (quote posts) for v2.

Compute `initials` from `post.name` (first letter of first + last word,
uppercased) as the fallback for broken avatars.

### 4. Image embed slot

- Render `.buzz-embed` only when `post.embedImage` is truthy.
- Aspect ratio: **16:9** (`aspect-ratio: 16 / 9`). Image is `object-fit: cover`.
- When an embed is present, drop the text clamp from 3 to 2 lines so the
  total card height stays close to the no-embed case.

### 5. External link affordance

A persistent ↗ glyph in the top-right of each card, faded by default,
strengthens on hover. Already covered in the CSS block below
(`.buzz-ext`).

### 6. Footer attribution

A small **"via Bluesky"** row appended after `.buzz-list`. CSS class
`.buzz-footer`; the existing list loses its bottom border-radius (use the
`.buzz-has-footer` modifier on `#sideRailBuzz`, or unconditionally pair
list + footer in this revision and adjust radii accordingly).

```html
<div class="buzz-footer">via <span>Bluesky</span></div>
```

---

## Design tokens

All values lifted from `styles.css :root` + `.pulse` overrides. Do not
introduce new tokens.

| Token            | Value      | Used for                                  |
|------------------|------------|-------------------------------------------|
| `--p-card`       | `#172B4D`  | Module bg                                 |
| `--p-card2`      | `#1E3A5F`  | (unused in this scope)                    |
| `--p-border`     | `#2C4A7F`  | Module border + row dividers              |
| `--p-text`       | `#e8eaf0`  | Author name, body emphasis                |
| `--p-muted`      | `#9aa0a8`  | Time, body text, footer                   |
| `--p-accent`     | `#cfd3dc`  | Currently used on tag (kept as fallback)  |
| `--accent`       | `#FF5910`  | Active filter chip                        |

### Category dot colors (new)

Defined as a single rule using `data-cat` selectors on `.buzz-tag`. These
are local to the module — do not promote to global tokens unless the rest
of Pulse adopts them.

| `data-cat`   | Dot color  | Notes                          |
|--------------|------------|--------------------------------|
| `insider`    | `#FF5910`  | Matches app accent             |
| `rumors`     | `#fca5a5`  | Soft red                       |
| `analytics`  | `#38bdf8`  | Sky-400                        |
| `league`     | `#facc15`  | Yellow-400                     |
| `team`       | `#4ade80`  | Green-400                      |
| `scouting`   | `#c084fc`  | Purple-400                     |

### Typography

| Element            | Size      | Weight | Color           |
|--------------------|-----------|--------|-----------------|
| Section title      | `.625rem` | 700    | `--p-muted`     |
| Filter chip        | `.68rem`  | 600    | `--p-muted` (inactive) / `#ffb088` (active) |
| Meta name          | `.75rem`  | 600    | `--p-text`      |
| Meta tag           | `.68rem`  | 600    | `--p-text` (dot is the color carrier) |
| Meta time          | `.68rem`  | 600    | `--p-muted`     |
| Body text          | `.8rem`   | 400    | `#c8cdd6`       |
| Footer attribution | `.625rem` | 500    | `--p-muted` (with `#b5c0d6` "Bluesky") |

### Spacing & geometry

| Property               | Value                |
|------------------------|----------------------|
| Card padding           | `0.75rem 0.875rem`   |
| Avatar size            | `28px × 28px` round  |
| Avatar–body gap        | `9px`                |
| Meta gap (flex)        | `6px`                |
| Embed aspect ratio     | `16 / 9`             |
| Embed border-radius    | `6px`                |
| Embed margin-top       | `7px`                |
| Filter chip padding    | `4px 9px`            |
| Filter chip radius     | `999px`              |
| Module border-radius   | `10px` (outer corners only) |

---

## CSS — drop-in replacement

Replace the existing `.buzz-*` block in `styles.css` (currently around
line 5095) with the block below. Also remove the `.game-count` mention
from the buzz header markup (the rule itself can stay — Games still uses
it).

```css
/* ============ Baseball Buzz (v2) ============ */
.buzz-list {
  background: var(--card);
  border: 1px solid var(--border);
  border-top: none;
  overflow: hidden;
}
.buzz-has-footer .buzz-list { border-radius: 0; }
.buzz-list:last-child { border-radius: 0 0 10px 10px; }

.buzz-filter-row {
  display: flex;
  gap: 6px;
  background: var(--card);
  border-left: 1px solid var(--border);
  border-right: 1px solid var(--border);
  padding: 8px 0.875rem 10px;
}
.buzz-chip {
  font-size: .68rem;
  font-weight: 600;
  padding: 4px 9px;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.04);
  color: var(--muted);
  border: 1px solid transparent;
  cursor: pointer;
}
.buzz-chip:hover { background: rgba(255, 255, 255, 0.07); }
.buzz-chip[aria-pressed="true"] {
  background: rgba(255, 89, 16, 0.12);
  color: #ffb088;
  border-color: rgba(255, 89, 16, 0.35);
}
.buzz-chip[disabled],
.buzz-chip[aria-disabled="true"] { opacity: 0.5; pointer-events: none; }

.buzz-card {
  display: block;
  position: relative;
  padding: 0.75rem 1.75rem 0.75rem 0.875rem;
  border-bottom: 1px solid rgba(255, 255, 255, 0.04);
  text-decoration: none;
  color: inherit;
  transition: background 0.15s;
}
.buzz-card:last-child { border-bottom: none; }
.buzz-card:hover { background: rgba(255, 255, 255, 0.06); }

.buzz-row {
  display: grid;
  grid-template-columns: 28px 1fr;
  gap: 9px;
}
.buzz-avatar {
  width: 28px;
  height: 28px;
  border-radius: 999px;
  object-fit: cover;
  flex-shrink: 0;
  background: linear-gradient(135deg, #2C4A7F, #1E3A5F);
}
.buzz-avatar-fallback {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-weight: 700;
  font-size: 11px;
}

.buzz-meta {
  display: flex;
  align-items: baseline;
  gap: 6px;
  font-size: .75rem;
  color: var(--text);
  margin-bottom: 3px;
  font-weight: 600;
}
.buzz-meta-name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.buzz-tag {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: .68rem;
  font-weight: 600;
  padding: 1px 6px;
  border-radius: 3px;
  background: rgba(255, 255, 255, 0.07);
  color: var(--text);
  flex-shrink: 0;
}
.buzz-tag::before {
  content: '';
  width: 6px;
  height: 6px;
  border-radius: 999px;
  background: var(--cat, var(--accent, #cfd3dc));
}
.buzz-tag[data-cat="insider"]   { --cat: #FF5910; }
.buzz-tag[data-cat="rumors"]    { --cat: #fca5a5; }
.buzz-tag[data-cat="analytics"] { --cat: #38bdf8; }
.buzz-tag[data-cat="league"]    { --cat: #facc15; }
.buzz-tag[data-cat="team"]      { --cat: #4ade80; }
.buzz-tag[data-cat="scouting"]  { --cat: #c084fc; }

.buzz-time {
  font-size: .68rem;
  color: var(--muted);
  font-weight: 600;
  margin-left: auto;
  flex-shrink: 0;
}

.buzz-text {
  font-size: .8rem;
  line-height: 1.45;
  color: #c8cdd6;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.buzz-has-embed .buzz-text { -webkit-line-clamp: 2; }

.buzz-embed {
  margin-top: 7px;
  border-radius: 6px;
  overflow: hidden;
  aspect-ratio: 16 / 9;
  border: 1px solid rgba(255, 255, 255, 0.06);
  background: #0e1a2e;
}
.buzz-embed img { width: 100%; height: 100%; object-fit: cover; display: block; }

.buzz-ext {
  position: absolute;
  top: 10px;
  right: 10px;
  color: var(--muted);
  opacity: 0;
  transition: opacity 0.15s;
  font-size: 11px;
  line-height: 1;
  pointer-events: none;
}
.buzz-card:hover .buzz-ext { opacity: 0.7; }

.buzz-footer {
  background: var(--card);
  border: 1px solid var(--border);
  border-top: none;
  border-radius: 0 0 10px 10px;
  padding: 6px 0.875rem 8px;
  text-align: right;
  font-size: 10px;
  color: var(--muted);
  font-weight: 500;
}
.buzz-footer span { color: #b5c0d6; }

.buzz-empty {
  background: var(--card);
  border: 1px solid var(--border);
  border-top: none;
  border-radius: 0 0 10px 10px;
  color: var(--muted);
  font-size: .72rem;
  padding: 16px;
  text-align: center;
}
```

---

## JS — `src/pulse/baseball-buzz.js` notes

Keep the file's current structure (keyless `app.bsky.feed.getAuthorFeed`,
`Promise.allSettled` fan-out, localStorage cache, 10-post cap, 30-day
freshness). Add:

1. **In `fetchAccount()`**, when building `out.push({...})`, also capture:
   - `avatar: p.author?.avatar || null`
   - `category: acct.category || 'team'` (read from `BASEBALL_BUZZ_ACCOUNTS` — see config change below)
   - `embedImage: extractEmbedImage(p.embed)` — small helper that returns the first `app.bsky.embed.images#view` thumb URL or `null`.

2. **Bump `CACHE_KEY`** to `mlb_buzz_cache_v2` so old shape (without
   avatar / category / embedImage) doesn't replay.

3. **`buzzHeader()`** takes no arg. Returns just the title row.

4. **Add `renderFilterRow()`** that emits the three chips with
   `aria-pressed` reflecting `state.baseballBuzzFilter`. Wire a delegated
   click handler in `loadBaseballBuzz` (event-delegation on `#sideRailBuzz`)
   that flips `state.baseballBuzzFilter`, writes to localStorage, and calls
   `renderBaseballBuzz()`.

5. **In `renderBaseballBuzz()`**, filter `posts` by
   `state.baseballBuzzFilter` before rendering:
   - `all` → no filter
   - `team` → `p.category === 'team' && p.tag === selectedTeamName`
   - `insider` → `p.category === 'insider' || p.category === 'rumors'`

6. **Avatar render**: use a real `<img>` with `onerror` swapping for a
   `<span class="buzz-avatar buzz-avatar-fallback">` of initials. Compute
   initials from `post.name`.

7. **Footer**: append after `.buzz-list`. Add `buzz-has-footer` class to
   the `#sideRailBuzz` wrapper so the list radius zeroes out.

---

## Config — `src/config/buzz.js`

Add a `category` field to every entry. Suggested mapping (apply
verbatim — the comment block already explains hand-curation):

| Existing `tag`                        | New `category` |
|---------------------------------------|----------------|
| `League`                              | `league`       |
| `Rumors`                              | `rumors`       |
| `Analytics`, `FanGraphs`, `ZiPS`, `Stats` | `analytics` |
| `Prospects`, `MLB.com`                | `league`       |
| `Insider`, `Athletic`                 | `insider`      |
| `Scouting`                            | `scouting`     |
| Anything else (team beat writers)     | `team`         |

Example:

```js
{ handle: 'kenrosenthal.bsky.social', name: 'Ken Rosenthal', tag: 'Insider',  category: 'insider' },
{ handle: 'bryanhoch.bsky.social',    name: 'Bryan Hoch',    tag: 'Yankees',  category: 'team'    },
```

---

## State

| State key                | Where                      | Default | Persisted to          |
|--------------------------|----------------------------|---------|-----------------------|
| `baseballBuzzPosts`      | existing                   | `[]`    | `mlb_buzz_cache_v2` (10 min) |
| `baseballBuzzFilter`     | **new** in `src/state.js`  | `'all'` | `mlb_buzz_filter_v1`  |

Add `baseballBuzzFilter` to the `state` object alongside the existing
`baseballBuzzPosts`, and hydrate it from localStorage in the same
init block that hydrates other persisted toggles.

---

## Loading / empty / error states

Unchanged from v4.28.2:

- **Loading** — `<div class="buzz-empty">Loading…</div>` after header
- **Empty** — `<div class="buzz-empty">No recent posts</div>`
- **Error** — `<div class="buzz-empty">Buzz feed unavailable</div>`

In all three cases there's **no filter row and no footer** — they're
list-mode-only.

---

## Acceptance criteria

1. `#sideRailBuzz` renders below the games list (placement unchanged).
2. Section header reads "Baseball Buzz" only — no count badge anywhere.
3. Each card shows: avatar (with initials fallback), name, tag with
   coloured dot, right-aligned relative time, 3-line text clamp (2 lines
   when an image embed is present).
4. Hovering a card shows a faint ↗ in the top-right.
5. Filter chips row: All / My team / Insiders. Selection persists across
   reload via `localStorage`. "My team" is disabled when no team is
   selected.
6. Footer reads "via **Bluesky**", aligned right, accent on "Bluesky".
7. Loading / empty / error states unchanged in copy; no filter row or
   footer shown in those states.
8. `package.json` bumped to `4.29.0`; `npm run build` propagates to
   `sw.js` CACHE and `index.html` cache-bust query strings — verify after
   build.
9. `CHANGELOG.md` + `CLAUDE.md` updated with a v4.29.0 entry. Suggested:

   > **v4.29.0** — Baseball Buzz visual revision: 28px author avatars
   > (Bluesky CDN, initials fallback), 13/12px type, category-coloured
   > tag pills, hover ↗ affordance, image-embed slot (drops text clamp
   > 3 → 2 lines when present), All/My-team/Insiders filter chips
   > (`localStorage`-persisted), "via Bluesky" footer. Section
   > count-badge removed (always 10, redundant). Cache key bumped to
   > `mlb_buzz_cache_v2`. Placement (below games) unchanged.

---

## Files in this bundle

- `README.md` — this document
- `buzz-v2-mock.html` — visual reference, seven artboards layering each
  change on top of v4.28.2
- `design-canvas.jsx` — supporting component used by the mock (not for
  production use)
