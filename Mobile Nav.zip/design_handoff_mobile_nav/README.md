# Handoff — Mobile Nav Refinement

## Overview

This package implements **Direction A** from the mobile nav audit: a focused refinement of the mobile top header and bottom navigation in the MLB Pulse app, plus eight cross-cutting nav-system behaviors and a unified section-bar pattern. Direction B (broadcast-first IA reframe) is deliberately deferred — see `01-design-reference.html` § 06 for context, but **do not implement it in this pass.**

This work touches three files in the app codebase:
- `styles.css` — primary file, ~80 lines added/changed
- `index.html` — markup additions for the new "More" tab + sheet, section-crumb span, dot indicators
- A new small JS module for hide-on-scroll, state preservation, hashchange routing, and long-press

---

## About the design files

The HTML in `01-design-reference.html` is a **design reference**, not production code. It's a single self-contained file that draws phone-shaped mockups in CSS so we can compare current state against the proposal. Do not copy from it directly — recreate the changes in the live app codebase (`styles.css` + `index.html` + a new JS module), preserving the existing class names and DOM structure described below.

## Fidelity

**High-fidelity.** All measurements, colors, easings, and breakpoints in this README are intentional. When in doubt, match the values exactly. The active codebase already has the right design system (`var(--accent)`, `var(--border)`, `var(--header-h)`, etc.) — use those tokens, never hardcode.

---

## Read in this order

1. **`01-design-reference.html`** — open it in a browser. Section 01 shows current state with annotations. Section 02 lists six visual issues. Section 03 lists eight behavioral issues. Section 04 specifies Direction A. Section 05 specifies the cross-section pattern. Skip section 06 (Direction B).
2. **This README** — implementation guide. Walk through Phases 1 → 4 in order. Each phase is independently shippable.
3. **`styles.css` in the app repo** — locations are referenced by line number throughout this README; line numbers refer to the version of `styles.css` that was current when this handoff was written. Use grep (e.g. `grep -n "@media(max-width:480px)" styles.css`) if line numbers have drifted.

---

## Implementation phases

| Phase | Scope | Risk | Approx LOC |
|---|---|---|---|
| **1** | Visual fixes to global header + bottom nav (mobile only) | Low | ~50 |
| **2** | Pulse top-strip refinement (`#pulseTopBar`) + radio toggle | Low | ~30 |
| **3** | Cross-section pattern: `.section-bar` + Yesterday/Stats updates | Medium | ~80 |
| **4** | Behavioral upgrades: hide-on-scroll, state preservation, hashchange, dot indicators, long-press, safe-area-top | Medium | ~150 JS + small CSS |

Ship Phase 1 first as its own PR. Phases 2–4 can stack in any order.

---

## Design tokens — read these before writing any CSS

The codebase already has these tokens. **Use them. Do not introduce new color values or magic numbers.**

```
--primary:        team primary (e.g. #002D72 Mets navy)
--secondary:      team secondary (e.g. #FF5910 Mets orange)
--accent:         action accent  (e.g. #FF8A52)
--header-text:    #fff on team color
--dark:           page bg, ~#0d1830 in dark theme
--card:           card bg slightly lighter than dark
--card2:          card bg lighter still
--border:         subtle border, ~#2a3866
--text:           primary text on dark
--muted:          secondary text on dark
--header-h:       60px desktop — see Phase 1 for mobile override
--radius:         card radius
--radius-pill:    full pill
--eyebrow-sz:     ~.66rem  (uppercase eyebrow type)
--eyebrow-ls:     ~.14em   (uppercase letter-spacing)
```

Spacing increments in this codebase trend in 4px (0.25rem) steps. Stay on that grid.

Easing for all nav-related transitions: `cubic-bezier(0.32, 0.72, 0, 1)` — iOS-style. Duration 220ms unless specified otherwise. **Do not use `ease`, `ease-in-out`, or shorthand without specifying** — the existing app uses bespoke curves and consistency matters.

Touch targets: **never below 44×44 CSS px**. Bottom-nav icons may be larger but the hit area must clear 44px. iOS HIG rule.

---

## Phase 1 — Visual fixes to global nav (ship first)

**Goal:** Fix four concrete bugs in the mobile chrome:
1. Settings button becomes unreachable when the user scrolls (header is `position:static` on mobile).
2. Bottom nav has 7 destinations packed into ~390px → labels at 9.5px are sub-legible.
3. `#gameTicker` sticky offset uses `var(--header-h)` (= 60px), which is wrong when the mobile header isn't sticky — leaves a 60px gap above the ticker.
4. Header doesn't respect `env(safe-area-inset-top)` → on installed PWA on notched iPhones, it crashes into the status bar.

### 1a. CSS changes — mobile breakpoint

Find the existing `@media(max-width:480px)` block (currently around line 2156 of `styles.css`). Modify the rules within it as follows:

```css
@media (max-width: 480px) {
  /* ── header: sticky on mobile, slimmer, safe-area-aware ───────── */
  header {
    position: sticky;                        /* was: static */
    top: 0;
    height: 42px;                            /* was: 60px (default) */
    padding: env(safe-area-inset-top) 12px 0;
    justify-content: space-between;
  }

  /* update --header-h so #gameTicker / #ydSectionBar stick flush */
  :root { --header-h: 42px; }

  /* keep .team-chip hidden as it already is */

  /* ── bottom nav: 5 destinations, larger touch targets ─────────── */
  nav button {
    flex: 1;
    min-width: 0;
    padding: 8px 2px 6px;
    min-height: 60px;                        /* was: 56px */
    font-size: 1.4rem;                       /* was: 1.15rem (icon) */
    gap: 4px;
  }
  nav button .nav-label {
    font-size: 11px;                         /* was: 9.5px */
    font-weight: 600;
    letter-spacing: .01em;
  }

  /* hide tabs 5–7 of the existing 7-tab bar (News, Standings, Stats);
     they re-surface from the new "More" sheet (markup below) */
  nav button[data-section="news"],
  nav button[data-section="standings"],
  nav button[data-section="stats"] {
    display: none;
  }

  /* ── section-crumb in header (shown on mobile only) ───────────── */
  .header-crumb {
    display: inline-block;
    margin-left: 8px;
    padding-left: 8px;
    border-left: 1px solid rgba(255,255,255,.18);
    font-size: 9.5px;
    font-weight: 700;
    letter-spacing: .16em;
    color: rgba(255,255,255,.55);
    text-transform: uppercase;
  }
}
```

> **Design-floor rules** (do not "improve" past these):
> - Header height **must not** drop below 42px on mobile. We need room for `--accent` underline + tappable ⚙ button.
> - Bottom-nav label **must not** drop below 11px. iOS HIG floor; we tested 9.5px and it failed.
> - Do **not** introduce a gradient on either bar. Use solid `var(--primary)` (header) and `color-mix(in srgb, var(--primary) 94%, transparent)` over `backdrop-filter: blur(20px)` (bottom nav, already in place — keep it).
> - Do **not** round the bottom-nav top corners. It's a flush bar, not a card.

### 1b. Markup changes — `index.html`

In the existing `<header>`, after the team wordmark span, add:

```html
<span class="header-crumb" id="headerCrumb">PULSE</span>
```

This empty-by-default span gets populated by the section-routing JS in Phase 4 (or you can hardcode "PULSE" for now and update via existing section-switch handler — search for the function that sets `.section.active`).

In the existing `<nav>`, **remove** the `News`, `Standings`, and `Stats` `<button>`s' visibility on mobile by adding `data-section="news"` / `data-section="standings"` / `data-section="stats"` to those existing buttons (the CSS above hides them on mobile).

Then **add a new "More" button** at the end of `<nav>`:

```html
<button class="nav-btn" data-section="more" aria-label="More" aria-haspopup="dialog">
  <span aria-hidden="true">⋯</span>
  <span class="nav-label">More</span>
</button>
```

### 1c. The "More" sheet

Create a bottom-sheet component containing the three hidden destinations + their existing icons. Match `.settings-panel`'s visual treatment but with a different positioning behavior on mobile:

```css
.more-sheet {
  position: fixed;
  left: 0;
  right: 0;
  bottom: calc(72px + env(safe-area-inset-bottom));  /* sits above the bottom nav */
  background: var(--card);
  border-top: 1px solid var(--border);
  border-radius: 16px 16px 0 0;
  padding: 16px 16px calc(16px + env(safe-area-inset-bottom));
  transform: translateY(120%);
  transition: transform 220ms cubic-bezier(0.32, 0.72, 0, 1);
  z-index: 90;
  box-shadow: 0 -8px 32px rgba(0,0,0,.4);
}
.more-sheet.open { transform: translateY(0); }

.more-sheet-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
}
.more-sheet-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  padding: 14px 8px;
  background: var(--dark);
  border: 1px solid var(--border);
  border-radius: 12px;
  font-size: 11px;
  font-weight: 600;
  color: var(--text);
}
.more-sheet-item .icon { font-size: 1.4rem; }
.more-sheet-backdrop {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,.4);
  opacity: 0;
  pointer-events: none;
  transition: opacity 220ms;
  z-index: 89;
}
.more-sheet-backdrop.open { opacity: 1; pointer-events: auto; }
```

**Behavior:** tapping `.nav-btn[data-section="more"]` toggles `.open` on both the sheet and backdrop. Tapping a sheet item closes the sheet AND switches the section using the existing section-routing function. Tapping the backdrop closes the sheet without switching. Pressing Escape closes it. **Do not add a header/title bar to the sheet** — the three icon+label items are sufficient.

### 1d. Phase 1 acceptance checklist

- [ ] Header stays visible at the top of the viewport while scrolling on a 390×844 viewport.
- [ ] ⚙ Settings button is tappable from any scroll depth.
- [ ] Bottom nav shows exactly 5 buttons on mobile: Pulse, My Team, Schedule, League, More.
- [ ] Tapping More opens a sheet with News, Standings, Stats; tapping any sheet item switches section and closes sheet.
- [ ] On scroll, no transparent gap appears above `#gameTicker` between header and ticker.
- [ ] Installed as PWA on iPhone 14+, header content sits below the status bar (not under it).
- [ ] Bottom-nav labels read clearly at arm's length (11px, not 9.5px).
- [ ] No layout shift / no hidden overflow on widths 360, 375, 390, 414, 430.
- [ ] Desktop (>480px) is **unchanged**.

---

## Phase 2 — `#pulseTopBar` refinement

**Goal:** Reduce the 5 right-side controls to **2 stateful toggles** (My Team Lens, Radio On/Off) plus an overflow `⋯` that reveals Sound, Yesterday-jump, and Theme. Currently the bar conflates state-bearing toggles and stateless launchers in identical pill shapes.

### Why Radio stays inline

Radio is a primary broadcast control — toggling it on/off changes the audio environment of the whole app. Like the My Team Lens, it has on/off state and the user wants its state visible at all times. The other three (Sound panel, Yesterday-jump, Theme) are launchers / non-toggles and belong in overflow.

### CSS changes

The `#pulseTopBar` rules are around line 2469 of `styles.css`. Add:

```css
@media (max-width: 480px) {
  #pulseTopBar {
    gap: 6px;
    padding: 8px 12px;
  }

  /* The two stateful pills (lens + radio) — keep visible */
  #pulseTopBar .ptb-toggle {
    flex-shrink: 0;
  }

  /* Hide the launcher pills (sound/yesterday/theme) inline; they
     surface from the overflow sheet instead */
  #pulseTopBar .ptb-launcher { display: none; }

  /* Overflow ⋯ trigger */
  #pulseTopBar .ptb-overflow {
    width: 26px;
    height: 26px;
    border-radius: 8px;
    border: 1px solid var(--border);
    background: transparent;
    color: var(--muted);
    font-weight: 900;
    font-size: 14px;
    line-height: 1;
    display: flex;
    align-items: center;
    justify-content: center;
  }
}
```

### Markup changes

In the existing `#pulseTopBar`:
1. Add class `ptb-toggle` to the existing **My Team Lens** button and the **Radio** toggle button.
2. Add class `ptb-launcher` to the existing **Sound**, **Yesterday-jump**, and **Theme** buttons.
3. Add a new `<button class="ptb-overflow" aria-label="More controls">⋯</button>` at the end of `.ptb-acts`.

### Overflow sheet (Pulse)

Reuse the same `.more-sheet` component from Phase 1 (a second instance, with class `.pulse-overflow-sheet`). It contains: Sound, Yesterday, Theme — same icons and existing handlers; just relocated trigger.

### Design floors
- The lens and radio pills **must** show their on/off state visibly. Keep the existing track+knob toggle pattern. If you change them to flat pills, you've broken the affordance.
- The `⋯` button **must not** look like the two toggle pills next to it. It's a 26×26 square with thin border, not a pill — that visual contrast is intentional and tells the user "different kind of thing."

---

## Phase 3 — Cross-section pattern: `.section-bar`

**Goal:** Define a single section-bar component all sections share, and migrate Yesterday + Stats to use it.

### The shared component

```css
.section-bar {
  position: sticky;
  top: var(--header-h);
  z-index: 80;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.75rem;
  padding: 0.5rem 0.875rem;
  background: var(--dark);
  border-bottom: 1px solid var(--border);
}

.section-bar > .section-bar-eyebrow {     /* left: section name */
  display: flex;
  align-items: center;
  gap: 7px;
  font-size: var(--eyebrow-sz);
  font-weight: 900;
  letter-spacing: var(--eyebrow-ls);
  color: var(--muted);
  text-transform: uppercase;
  flex-shrink: 0;
}
.section-bar > .section-bar-eyebrow .ico {
  color: var(--accent);
}

.section-bar > .section-bar-context {     /* center: date / score / filter */
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  min-width: 0;
}

.section-bar > .section-bar-toggles {     /* right: stateful pills only */
  display: flex;
  gap: 6px;
  flex-shrink: 0;
}

.section-bar > .section-bar-overflow {    /* right: ⋯ for launchers */
  flex-shrink: 0;
}
```

### Migrating `#pulseTopBar`
Refactor it to be `<div id="pulseTopBar" class="section-bar">…</div>`. The existing brand `⚡ MLB PULSE` is the eyebrow slot. Lens + Radio go in `.section-bar-toggles`. The `⋯` from Phase 2 goes in `.section-bar-overflow`. There is no center/context content for Pulse.

### Migrating `#ydSectionBar` (Yesterday)

The Yesterday top strip currently mirrors Pulse's content (brand + 5 pills). That's wrong for a recap viewer — the primary control should be the **date scrubber**.

```html
<div id="ydSectionBar" class="section-bar">
  <span class="section-bar-eyebrow"><span class="ico">◷</span>YESTERDAY</span>

  <div class="section-bar-context">
    <button class="yd-date-step" aria-label="Previous day">‹</button>
    <span class="yd-date-label">SUN · 5/4</span>
    <button class="yd-date-step" aria-label="Next day">›</button>
  </div>

  <button class="section-bar-overflow" aria-label="More">⋯</button>
</div>
```

Drop the lens / sound / theme pills inline — they go in the overflow sheet (consistent with Pulse).

### Migrating `.stat-tabs` and `.boxscore-tabs`

The current `.stat-tabs` rule (around line 1273) uses `flex-wrap: wrap` — on a phone with 5+ tabs, the row wraps onto 2–3 lines and the active tab's screen position jumps as the row reflows. Switch to a horizontal scroller:

```css
@media (max-width: 480px) {
  .stat-tabs,
  .boxscore-tabs {
    flex-wrap: nowrap;                    /* was: wrap */
    overflow-x: auto;
    scrollbar-width: none;                /* Firefox */
    -webkit-mask-image: linear-gradient(
      to right,
      #000 calc(100% - 28px),
      transparent
    );
    padding-right: 28px;
  }
  .stat-tabs::-webkit-scrollbar,
  .boxscore-tabs::-webkit-scrollbar { display: none; }

  .stat-tab,
  .boxscore-tabs > * {
    flex-shrink: 0;
  }
}
```

Plus a small JS to scroll the active tab into view when it changes (use `scrollIntoView({block: 'nearest', inline: 'center', behavior: 'smooth'})` — **but only on the tabs container, not the page**; the global "no scrollIntoView" guidance is for the page document, not internal scrollers).

### Phase 3 acceptance checklist
- [ ] Pulse, Yesterday, and any future section all use `<div class="section-bar">` with the same slot structure.
- [ ] Yesterday's date scrubber is the primary visual element of its bar.
- [ ] Stat tabs scroll horizontally on mobile with a soft-fade right edge; active tab scrolls into view on change.
- [ ] All section bars stick flush below the header (no transparent gap).

---

## Phase 4 — Behavioral upgrades

These are the items in `01-design-reference.html` § 03. Each is independently shippable; ship the easiest first to build a habit.

Create `js/nav-behavior.js` (or wherever the codebase's nav module lives) and add the following behaviors:

### 4a. Hide-on-scroll for bottom nav

```js
// Hide bottom nav when scrolling down past 40px; restore on scroll-up.
let lastY = 0;
let nav = document.querySelector('nav');
let ticking = false;
window.addEventListener('scroll', () => {
  if (ticking) return;
  ticking = true;
  requestAnimationFrame(() => {
    const y = window.scrollY;
    const goingDown = y > lastY && y > 40;
    nav.classList.toggle('nav-hidden', goingDown);
    lastY = y;
    ticking = false;
  });
}, { passive: true });
```

```css
nav { transition: transform 220ms cubic-bezier(0.32, 0.72, 0, 1); }
@media (max-width: 480px) {
  nav.nav-hidden { transform: translateY(110%); }
  /* 110% rather than 100% so the nav clears its own bottom shadow */
}
```

> **Design floor:** restore the nav within 220ms of any scroll-up. Lag here feels broken. Do not require the user to scroll up by more than 1px; any negative delta restores.

### 4b. Tab state preservation

Each section is its own scroll container. Save scroll position to a `Map` when the user leaves a section; restore it when they come back. Pseudo:

```js
const scrollMemory = new Map();
function showSection(name) {
  const current = document.querySelector('.section.active');
  if (current) scrollMemory.set(current.id, window.scrollY);
  // ... existing section-switch logic ...
  const restored = scrollMemory.get(name) ?? 0;
  window.scrollTo({ top: restored, behavior: 'instant' });
}
```

Also preserve in-section state where it exists (selected date in Yesterday, expanded matchup in Pulse) — store in the existing state object, not in JS-level Maps. The codebase likely already has section state; just stop resetting it on switch.

### 4c. Hashchange routing

```js
function navTo(section) {
  if (location.hash !== `#${section}`) {
    location.hash = section;          // triggers hashchange
  } else {
    showSection(section);             // already there → just re-show
  }
}
window.addEventListener('hashchange', () => {
  const target = location.hash.slice(1) || 'pulse';
  showSection(target);
});
// On load:
showSection(location.hash.slice(1) || 'pulse');
```

Wire all `nav button` clicks to `navTo(button.dataset.section)`. Result: browser back/forward works, refresh preserves section, deep links land correctly.

### 4d. Live-state dot indicators

Add a small dot to nav buttons when there's a notable state in their destination:

```css
.nav-btn { position: relative; }
.nav-dot {
  position: absolute;
  top: 8px;
  right: calc(50% - 18px);
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--accent);
  box-shadow: 0 0 0 2px var(--primary);
}
.nav-dot.live {
  background: #22c55e;
  animation: nav-dot-pulse 1.6s ease-in-out infinite;
}
@keyframes nav-dot-pulse {
  0%, 100% { opacity: 1;   transform: scale(1); }
  50%      { opacity: .55; transform: scale(1.18); }
}
```

Wire to existing app state: green pulsing dot on Schedule when user's team is live; orange dot on More when News has a breaking item; orange dot on My Team when a new card unlocked. Reuse the same data the existing toast system reads.

### 4e. Long-press shortcuts

```js
function attachLongPress(el, handler, ms = 500) {
  let timer = null;
  const start = () => { timer = setTimeout(() => { handler(); navigator.vibrate?.(8); }, ms); };
  const cancel = () => { clearTimeout(timer); };
  el.addEventListener('pointerdown', start);
  el.addEventListener('pointerup', cancel);
  el.addEventListener('pointercancel', cancel);
  el.addEventListener('pointerleave', cancel);
  el.addEventListener('contextmenu', e => e.preventDefault());
}
```

Attach to each nav button with a destination-specific shortcut handler:
- `Pulse` long-press → menu with [Demo Mode, Mute all, Open Cards]
- `My Team` long-press → menu with [Switch team]
- `Schedule` long-press → menu with [Today, This week, Postseason]

The menu can reuse the bottom-sheet component from Phase 1.

### 4f. Bottom-sheet for `.settings-panel` on mobile

The existing `.settings-panel` uses `position: absolute` with `width: 280px`. On 360px screens this overflows. Add a mobile override:

```css
@media (max-width: 480px) {
  .settings-panel {
    position: fixed;
    left: 0;
    right: 0;
    top: auto;
    bottom: 0;
    width: auto;
    border-radius: 16px 16px 0 0;
    transform: translateY(100%);
    transition: transform 220ms cubic-bezier(0.32, 0.72, 0, 1);
    padding-bottom: calc(16px + env(safe-area-inset-bottom));
  }
  .settings-panel.open { transform: translateY(0); }
}
```

### Phase 4 acceptance checklist
- [ ] Bottom nav slides off on scroll-down; reappears on scroll-up within 220ms.
- [ ] Tab switching preserves scroll position per section.
- [ ] Browser back navigates between visited sections.
- [ ] Refresh keeps you on your current section.
- [ ] Deep link `app.com/#schedule` loads directly into Schedule.
- [ ] Live dot pulses green on Schedule when user's team game is live.
- [ ] Long-pressing Pulse opens the shortcut sheet with haptic feedback (where supported).
- [ ] Mobile settings sheet slides up from the bottom; tapping the backdrop dismisses it.

---

## Things to avoid (Claude Code, read this twice)

1. **Don't add new colors.** Every color must come from `var(--…)`. If you find yourself typing a `#hex`, stop and find the right token.
2. **Don't add gradients.** None of the proposals call for gradients. The app's visual language is solid blocks of team color + accent. Gradients in nav chrome look like generic SaaS, not a sports app.
3. **Don't make the bottom nav float.** It's a flush bar against the bottom edge with `backdrop-filter`. Adding margin or radius makes it look like an Android bottom-sheet, which it isn't.
4. **Don't add icons to the section-bar eyebrow.** The eyebrow is text. The one exception is the small `⚡` (Pulse) and `◷` (Yesterday) glyphs — these are part of the wordmark, not standalone icons. Don't add `📅` to Schedule's eyebrow etc.; the section name carries the load.
5. **Don't redesign the active state.** The current accent color + 2px inset stripe is the agreed pattern. Adding fills, shadows, scaling, or animation to active-tab is out of scope — section 03 of the design reference adds *informative* state on top (dots, counters), not *decorative* state.
6. **Don't introduce new fonts or weights.** The codebase uses system stack with weights 400/500/600/700/900. Stay there.
7. **Don't add transitions to the active-tab indicator.** It should be instant on tap. Smooth motion here delays the user's feedback that their tap registered.
8. **Don't increase the bottom-nav height past 60px on mobile.** It already eats 14% of viewport at 60px; we can't afford more. If a label doesn't fit at 11px, the label wording is wrong, not the size.
9. **Don't reuse the desktop `.settings-panel` positioning on mobile.** It's a different component pattern at small breakpoints (bottom sheet, not anchor-positioned popover). Phase 4f handles this.
10. **Don't wire `scrollIntoView` against the document.** Only against internal scrollers (e.g., the `.stat-tabs` row). Document-level `scrollIntoView` breaks the app.

---

## Files in this package

- `01-design-reference.html` — the audit + Direction A + cross-section pattern, with phone-frame mockups. Reference only.
- `README.md` — this file. Implementation guide.

## Files in the app codebase that this work touches

- `styles.css` — primary changes.
- `index.html` — markup additions for crumb span, More button, More sheet, overflow buttons in `#pulseTopBar` and `#ydSectionBar`.
- A new `js/nav-behavior.js` (Phase 4) — exposes `navTo()`, `attachLongPress()`, scroll-memory, hashchange listener.

## Out of scope for this handoff

- Direction B (broadcast-first IA reframe). Don't implement.
- Desktop nav. Phase 1's CSS is gated to `@media (max-width: 480px)`; desktop is untouched.
- Any backend/data changes. Live-dot data sources should reuse what the toast system already reads.
- Onboarding / first-run UI. Out of scope.
