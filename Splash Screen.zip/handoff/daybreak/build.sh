#!/usr/bin/env bash
# Generate the full Daybreak splash image set + inject into index.html + update manifest.json.
# Run from repo root.
set -euo pipefail

mkdir -p icons/splash

npx pwa-asset-generator handoff/daybreak/splash-template.html icons/splash/ \
  --background "#0a1929" \
  --splash-only \
  --type png \
  --opaque true \
  --padding "0px" \
  --index index.html \
  --manifest manifest.json \
  --log true

echo "✔ Generated splash images in icons/splash/"
echo "✔ Updated index.html with apple-touch-startup-image links"
echo "✔ Updated manifest.json background_color"
echo ""
echo "Next:"
echo "  1. Review the generated <link> tags in index.html <head>"
echo "  2. Add icons/splash/* to sw.js precache list"
echo "  3. Bump CACHE constant in sw.js (e.g. 'pulse-v4.6.7')"
echo "  4. Commit and deploy"
