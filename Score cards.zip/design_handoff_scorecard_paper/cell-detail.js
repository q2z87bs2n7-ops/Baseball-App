// Renders the 3-cell outcome-hierarchy artboard (HR / K / groundout) for a variant.
window.renderCellDetail = function(variant){
  var fn = variant==='current' ? window.diamondCurrent
         : variant==='refined' ? window.diamondRefined
         : window.diamondPaper;
  var px = variant==='current' ? 80 : 110;

  var hr = { code:'HR', hit:true,  out:false, reached:3, scored:true,  rbi:3, b:1, s:2, p:5, hc:{x:60,y:50},   traj:'fly_ball' };
  var k  = { code:'ꓘ', hit:false, out:true,  reached:0, scored:false, rbi:0, outNum:1, b:0, s:3, p:4 };
  var go = { code:'6-3', hit:false, out:true, reached:0, scored:false, rbi:0, outNum:2, b:1, s:1, p:3, hc:{x:140,y:170}, traj:'ground_ball' };

  function block(cell, label, sub){
    return '<div class="cell-detail">'
         +   fn(cell, px)
         +   '<div class="cd-label">'+label+'</div>'
         +   '<div class="foot">'+sub+'</div>'
         + '</div>';
  }

  return ''
    + '<div class="sc-shell sc-shell--'+variant+'">'
    +   '<div class="sc-head">'
    +     '<div>'
    +       '<div class="sc-title">Outcome Hierarchy</div>'
    +       '<div class="sc-sub">Same input, three readings</div>'
    +     '</div>'
    +     '<div class="sc-variant-tag">'+variant.toUpperCase()+'</div>'
    +   '</div>'
    +   '<div class="sc-section-h">SCAN-READABILITY</div>'
    +   '<div class="cell-grid">'
    +     block(hr, 'Home Run',   '3 RBI · scored')
    +     block(k,  'Strikeout',  'Called · 1 out')
    +     block(go, 'Groundout',  '6-3 · 2 outs')
    +   '</div>'
    +   '<div class="foot" style="text-align:center;padding-top:8px;opacity:.6">'
    +     (variant==='current'
       ? 'All three cells visually equal-weight; you cannot scan a row and locate the runs.'
       : variant==='refined'
       ? 'HR fills the diamond. K dominates the cell. Groundout recedes. Hierarchy now reads at-a-glance.'
       : 'Filled red diamond + circled out + serif K. The page tells a story.')
    +   '</div>'
    + '</div>';
};
