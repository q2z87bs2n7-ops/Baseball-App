// Three diamond renderers: current (faithful), refined (dark, outcome hierarchy),
// paper (heritage). Same input cell, different visuals.

function esc(s){ return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;'); }

// Spray vector path (shared geometry, palette varies per variant).
function sprayPath(hc, traj, size){
  if(!hc) return null;
  var dx = hc.x - 125.42, dy = 198.27 - hc.y;
  var th = Math.atan2(dx, dy);
  if(th>1.05) th=1.05; else if(th<-1.05) th=-1.05;
  var rN = Math.sqrt(dx*dx+dy*dy)/210;
  if(rN>1) rN=1; else if(rN<0.12) rN=0.12;
  var L = 8 + rN*46;
  var ex = Math.max(4, Math.min(56, 30 + L*Math.sin(th)));
  var ey = Math.max(4, Math.min(56, 58 - L*Math.cos(th)));
  var vx = ex-30, vy = ey-57, vl = Math.sqrt(vx*vx+vy*vy)||1;
  var k = traj==='fly_ball' ? 7 : traj==='popup' ? 9 : traj==='line_drive' ? 2 : 0;
  var d = k>0
    ? 'M30,57 Q'+(((30+ex)/2)+(-vy/vl)*k).toFixed(1)+','+(((57+ey)/2)+(vx/vl)*k).toFixed(1)+' '+ex.toFixed(1)+','+ey.toFixed(1)
    : 'M30,57 L'+ex.toFixed(1)+','+ey.toFixed(1);
  return { d:d, ex:ex.toFixed(1), ey:ey.toFixed(1) };
}

// ── A: Current (faithful to src/overlay/scorecard.js) ─────────────────────
window.diamondCurrent = function(cell, size){
  size = size || 56;
  var H='30,58', B1='58,30', B2='30,2', B3='2,30';
  var path = ['M30,58 L58,30','M58,30 L30,2','M30,2 L2,30','M2,30 L30,58'];
  var s = '<svg viewBox="0 0 60 60" width="'+size+'" height="'+size+'">';
  s += '<polygon points="'+B2+' '+B1+' '+H+' '+B3+'" fill="none" stroke="var(--border)" stroke-width="1.5"/>';
  var sp = sprayPath(cell.hc, cell.traj);
  if(sp){
    s += '<path d="'+sp.d+'" stroke="var(--muted)" stroke-width="1.2" fill="none" opacity="0.55"/>';
    s += '<circle cx="'+sp.ex+'" cy="'+sp.ey+'" r="1.5" fill="var(--muted)" opacity="0.7"/>';
  }
  if(cell.scored) s += '<polygon points="'+B2+' '+B1+' '+H+' '+B3+'" fill="var(--accent)" fill-opacity="0.28"/>';
  var seg = cell.scored ? 4 : (cell.reached||0);
  for(var i=0;i<seg;i++){
    s += '<path d="'+path[i]+'" stroke="var(--accent)" stroke-width="3" stroke-linecap="round" fill="none"/>';
  }
  [B1,B2,B3].forEach(function(p,idx){
    var on = (idx+1) <= (cell.scored?3:cell.reached);
    s += '<circle cx="'+p.split(',')[0]+'" cy="'+p.split(',')[1]+'" r="2.6" fill="'+(on?'var(--accent)':'var(--border)')+'"/>';
  });
  if(cell.inningEnd) s += '<line x1="4" y1="4" x2="56" y2="56" stroke="var(--muted)" stroke-width="1.5" opacity="0.5"/>';
  if(cell.outNum) s += '<text x="51" y="13" font-size="9" fill="var(--muted)" text-anchor="middle">'+cell.outNum+'</text>';
  for(var ri=0; ri<(cell.rbi||0); ri++){
    s += '<circle cx="'+(6+ri*4)+'" cy="10" r="1.6" fill="var(--accent)"/>';
  }
  var col = cell.hit ? 'var(--accent)' : (cell.out ? 'var(--muted)' : 'var(--text)');
  s += '<text x="30" y="31" font-size="11" font-weight="700" fill="'+col+'" text-anchor="middle">'+esc(cell.code)+'</text>';
  s += '</svg>';
  return s;
};
