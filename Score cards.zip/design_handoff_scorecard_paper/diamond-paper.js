// ── C: Paper (heritage) ────────────────────────────────────────────────────
// Cream stock, navy ink for plays, faded red for outs, accent red fill on HR.
// Same SVG geometry as Refined; palette + stroke-character changed.
// (No texture — relies on the surrounding artboard for paper feel.)
window.diamondPaper = function(cell, size){
  size = size || 76;
  var H='30,58', B1='58,30', B2='30,2', B3='2,30';
  var path = ['M30,58 L58,30','M58,30 L30,2','M30,2 L2,30','M2,30 L30,58'];
  var isHR = cell.code === 'HR';
  var isK  = cell.code === 'K' || cell.code === 'ꓘ';

  var INK_NAVY = '#1a3a6e';
  var INK_RED  = '#a8243a';
  var INK_FAINT = '#b8a890';

  // Outs in red, plays in navy, HR fills in red.
  var ink = cell.out ? INK_RED : INK_NAVY;
  var pathStroke = cell.scored ? INK_NAVY : (cell.hit ? INK_NAVY : INK_FAINT);

  var s = '<svg viewBox="0 0 60 60" width="'+size+'" height="'+size+'">';
  // Perimeter — thinner, ink-on-paper feel
  s += '<polygon points="'+B2+' '+B1+' '+H+' '+B3+'" fill="none" stroke="'+INK_FAINT+'" stroke-width="0.8"/>';

  // Spray — pencil
  var sp = sprayPath(cell.hc, cell.traj);
  if(sp && !isK){
    s += '<path d="'+sp.d+'" stroke="'+INK_FAINT+'" stroke-width="0.9" fill="none" opacity="0.7"/>';
  }

  // HR: filled red
  if(isHR){
    s += '<polygon points="'+B2+' '+B1+' '+H+' '+B3+'" fill="'+INK_RED+'" fill-opacity="0.18" stroke="'+INK_RED+'" stroke-width="1.2"/>';
  }

  // Base path segments — slightly wavy stroke via stroke-linejoin
  var seg = cell.scored ? 4 : (cell.reached||0);
  for(var i=0;i<seg;i++){
    s += '<path d="'+path[i]+'" stroke="'+pathStroke+'" stroke-width="2.4" stroke-linecap="round" fill="none"/>';
  }

  // Base dots — small ink stains
  [B1,B2,B3].forEach(function(p,idx){
    var on = (idx+1) <= (cell.scored?3:cell.reached);
    s += '<circle cx="'+p.split(',')[0]+'" cy="'+p.split(',')[1]+'" r="2.1" fill="'+(on?pathStroke:'#d4c5a8')+'"/>';
  });

  // Inning-ending diagonal — red slash
  if(cell.inningEnd){
    s += '<line x1="3" y1="3" x2="57" y2="57" stroke="'+INK_RED+'" stroke-width="1.6" opacity="0.85"/>';
  }

  // Out number — circled (traditional scorebook convention)
  if(cell.outNum){
    s += '<circle cx="50" cy="10" r="5.5" fill="none" stroke="'+INK_RED+'" stroke-width="0.9"/>';
    s += '<text x="50" y="13" font-size="8.5" font-weight="700" fill="'+INK_RED+'" font-family="Georgia, serif" text-anchor="middle">'+cell.outNum+'</text>';
  }

  // RBI dots — small red filled circles, top-left
  for(var ri=0; ri<(cell.rbi||0); ri++){
    s += '<circle cx="'+(7+ri*4.5)+'" cy="9" r="1.6" fill="'+INK_RED+'"/>';
  }

  // Code — serif for the heritage feel
  var codeSize = isK ? 22 : (isHR ? 13 : 11);
  var codeY    = isK ? 38 : (isHR ? 32 : 31);
  var codeFamily = 'Georgia, "Times New Roman", serif';
  s += '<text x="30" y="'+codeY+'" font-size="'+codeSize+'" font-weight="700" font-family="'+codeFamily+'" fill="'+ink+'" text-anchor="middle">'+esc(cell.code)+'</text>';

  s += '</svg>';
  return s;
};
