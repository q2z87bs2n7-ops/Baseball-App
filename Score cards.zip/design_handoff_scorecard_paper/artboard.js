// Artboard helpers — line score + batter row for any of the 3 variants.

function lineScore(variant){
  var awayRuns = [0,1,3,'','','','','',''];
  var homeRuns = [0,0,0,'','','','','',''];
  var inns = '';
  for(var i=1;i<=9;i++) inns += '<th>'+i+'</th>';
  return ''
    + '<table class="ls ls--'+variant+'">'
    + '<thead><tr><th class="ls-team"></th>'+inns+'<th class="ls-tot">R</th><th class="ls-tot">H</th><th class="ls-tot">E</th></tr></thead>'
    + '<tbody>'
    +   '<tr><td class="ls-team">YANKEES</td>'+awayRuns.map(function(r){return '<td>'+r+'</td>';}).join('')+'<td class="ls-tot">4</td><td class="ls-tot">3</td><td class="ls-tot">0</td></tr>'
    +   '<tr><td class="ls-team">METS</td>'+homeRuns.map(function(r){return '<td>'+r+'</td>';}).join('')+'<td class="ls-tot">0</td><td class="ls-tot">2</td><td class="ls-tot">1</td></tr>'
    + '</tbody></table>';
}

function footCaption(c){
  if(c.b==null) return '';
  return '<div class="foot">'+c.b+'-'+c.s+(c.p?' · '+c.p+'p':'')+'</div>';
}

function batterGrid(diamondFn, opts){
  opts = opts || {};
  var fx = window.SC_FIXTURE;
  var rows = fx.lineup.map(function(p, idx){
    var c = fx.cells[idx];
    var cellHtml;
    if(c){
      cellHtml = '<div class="sc-cell'+(c.inningEnd?' inning-end':'')+'">'
               + diamondFn(c, opts.cellPx)
               + (opts.showFoot ? footCaption(c) : '')
               + '</div>';
    } else {
      cellHtml = '<div class="sc-cell empty"></div>';
    }
    // 9 columns — only inning 3 populated
    var inns = '';
    for(var i=1;i<=9;i++){
      inns += '<div class="sc-cell-wrap">' + (i===3 ? cellHtml : '<div class="sc-cell empty"></div>') + '</div>';
    }
    return ''
      + '<div class="row">'
      +   '<div class="row-name"><span class="ord">'+p.ord+'</span><span class="nm">'+p.name+'</span><span class="pos">'+p.pos+'</span></div>'
      +   inns
      + '</div>';
  }).join('');
  var head = '<div class="row row-h"><div class="row-name"></div>';
  for(var i=1;i<=9;i++) head += '<div class="sc-cell-wrap"><div class="ih">'+i+'</div></div>';
  head += '</div>';
  return '<div class="batter-grid">' + head + rows + '</div>';
}

window.renderArtboard = function(variant){
  var fn = variant==='current' ? window.diamondCurrent
         : variant==='refined' ? window.diamondRefined
         : window.diamondPaper;
  var px = variant==='current' ? 56 : 76;
  return ''
    + '<div class="sc-shell sc-shell--'+variant+'">'
    +   '<div class="sc-head">'
    +     '<div>'
    +       '<div class="sc-title">YANKEES @ METS</div>'
    +       '<div class="sc-sub"><span class="live-dot"></span>Top 3 · Citi Field · 2026-05-15</div>'
    +     '</div>'
    +     '<div class="sc-variant-tag">'+variant.toUpperCase()+'</div>'
    +   '</div>'
    +   '<div class="sc-section">'+lineScore(variant)+'</div>'
    +   '<div class="sc-section-h">YANKEES — BATTING</div>'
    +   batterGrid(fn, { cellPx:px, showFoot:variant!=='current' ? true : true })
    + '</div>';
};
