# Handoff: Old-School Scorecard — Paper variant

## Overview

A visual redesign of the Baseball-App `#scorecardOverlay` (currently at
v4.21.1, `src/overlay/scorecard.js` + `.sc-*` classes in `styles.css`).
The current dark/orange treatment doesn't earn the "Old-School Scorecard"
framing — it reads like every other surface in the app. This redesign
commits to the heritage idea: cream stock, navy ink, faded red for outs,
serif type. It also applies five concrete improvements to the diamond
cell itself so a row of plate appearances reads at-a-glance.

Two delivery options:

- **Variant toggle.** Add a "Paper / Dark" switch in Settings (or in the
  scorecard header) and ship both. Recommended.
- **Full replace.** Replace the current dark treatment outright. Faster
  to ship; loses no functionality.

This handoff documents the Paper variant in full and the five cell-level
improvements that apply regardless of variant.

## About the design files

The files in this bundle are **HTML design references** — prototypes
showing intended look and behaviour, not production code to copy. The
task is to **recreate this visual treatment inside the existing
Baseball-App codebase** (`src/overlay/scorecard.js` + `styles.css`)
using its established patterns: ES-module exports, `.sc-*` CSS class
naming, SVG diamond builder, no framework. Keep all existing model logic
(`buildModel`, runner tracking, fielder chains, etc.) — this is a
visual-only change.

## Fidelity

**High-fidelity.** Exact hex values, font stacks, sizes, and stroke
widths are given below. Reference `reference.html` for the rendered
target; `diamond-paper.js` shows the exact SVG geometry to reproduce.

## Files in this bundle

| File | What it is |
|---|---|
| `reference.html` | Open this — shows the full scorecard + cell-hierarchy detail at production size on a dark backdrop |
| `diamond-paper.js` | Production-equivalent SVG diamond renderer for the paper variant. Drop-in replacement signature for `diamondSVG()` in `src/overlay/scorecard.js` |
| `diamond-current.js` | The existing diamond renderer, for side-by-side comparison |
| `artboard.js` | Mock line-score + batter-grid scaffolding (reference only — the production scorecard already has equivalent code) |
| `cell-detail.js` | Renders the HR / K / groundout hierarchy comparison |
| `fixture.js` | Sample cell data shape — mirrors what `buildModel()` produces today |
| `artboard.css` | All CSS used by the mocks. The Paper section (`.sc-shell--paper { … }`) is the source of truth for the new palette |

## Design tokens — Paper variant

### Palette

| Token | Hex | Purpose |
|---|---|---|
| Paper cream | `#f4ecd8` | Background (with subtle radial-gradient stains, see below) |
| Ink navy | `#1a3a6e` | Primary type, hits, scoring base paths, run total backgrounds |
| Ink red | `#a8243a` | Outs (codes + circles), RBI dots, HR fill, inning-ending diagonal |
| Faint sand | `#c7b896` | Empty diamond perimeter, dotted row separators, table borders |
| Pencil mute | `#8a7d65` | Position abbreviations, footer (`b-s · #p`), italic meta, spray vectors |
| Stain spot 1 | `rgba(212,197,168,0.18)` | Radial gradient — top-left corner |
| Stain spot 2 | `rgba(212,197,168,0.22)` | Radial gradient — bottom-right corner |
| Empty base dot | `#d4c5a8` | Unreached bases on the diamond |

The cream background is **not flat** — it's two radial gradients
layered over `#f4ecd8` to suggest paper grain:

```css
background:
  radial-gradient(ellipse at 20% 10%, rgba(212,197,168,0.18), transparent 40%),
  radial-gradient(ellipse at 80% 90%, rgba(212,197,168,0.22), transparent 50%),
  #f4ecd8;
```

### Typography

| Element | Font | Size | Weight | Style |
|---|---|---|---|---|
| Game title (`.sc-title`) | Playfair Display | 1.05rem | 800 | italic, color navy |
| Subtitle (`.sc-sub`) | Georgia | 0.7rem | 400 | italic, color pencil |
| Variant tag / section header | Georgia | 0.55–0.62rem | 700 | italic, letter-spacing 0.12–0.18em, uppercase |
| Line-score body | Courier New mono | 0.7rem | 400/900 | tabular numerals |
| Line-score team labels | Georgia | 0.66rem | 700 | navy |
| Batter row name | Georgia | 0.74rem | 700 | navy |
| Batter row order # | Georgia | 0.74rem | 700 | red, opacity 0.85 |
| Batter row position | Georgia | 0.62rem | 400 | italic, pencil |
| Diamond code text | Georgia, "Times New Roman", serif | 11pt (default) / 13pt (HR) / 22pt (K) | 700 | navy or red |
| Out number | Georgia serif | 8.5pt | 700 | red, inside red-stroke circle |
| Foot caption (`b-s · #p`) | Courier New mono | 0.54rem | 400 | pencil |

Load Playfair Display from Google Fonts (already in the reference
HTML). Georgia/Courier are system fonts — no additional loads needed.

### Spacing & strokes

| Element | Value |
|---|---|
| Diamond cell size | **76px** (was 56px) |
| Diamond perimeter stroke | 0.8px, color faint sand |
| Reached-base path stroke | 2.4px, round caps, color navy |
| HR perimeter stroke (override) | 1.2px, color red |
| HR interior fill | red @ 0.18 alpha |
| Out-number circle | 5.5px radius, 0.9px red stroke, no fill |
| Inning-ending diagonal | 1.6px red stroke @ 0.85 opacity |
| Spray vector | 0.9px faint stroke @ 0.7 opacity (suppressed on K) |
| Base dot radius (reached) | 2.1px |
| Row separator | 1px dotted `rgba(199,184,150,0.7)` |
| Table border | 1px solid faint sand |
| Card padding | 18px 20px 22px |
| Section gap | 14px |

## The five cell-level improvements (apply in all variants)

These are scan-readability fixes to the diamond itself. The Paper
variant in `diamond-paper.js` already implements all five — they're
called out here so they survive into the production rewrite.

1. **Cell grew from 56px to 76px.** The batting grid already scrolls
   horizontally inside `.sc-scroll`, so there's no layout cost. The
   diamond now has room to breathe between the perimeter, the fielder
   code, the out chip, the RBI dots, and the spray vector.

2. **Outcome hierarchy.** Three play types get explicit visual weight:
   - **HR**: the diamond polygon is filled (red @ 0.18 alpha) with a red
     perimeter stroke. The code text is one tier larger (13pt vs 11pt).
   - **Strikeout (K / ꓘ)**: the glyph is rendered at **22pt centered**,
     dominating the cell. Drop the spray vector entirely on K cells.
   - **All other plays**: standard 11pt code, normal weight. They
     recede so HR and K pop.

3. **Accent restraint.** Red is reserved for **outs, RBI marks, the HR
   fill, and the inning-ending diagonal**. Hits that didn't score use
   **navy** for the base-path stroke. Non-reached bases use faint sand.
   A single that left the runner on first must not look the same as a
   triple that scored.

4. **Spray vector demoted.** Down from the current 55% opacity to
   ~70% opacity at 0.9px stroke in pencil mute — readable but
   ornamental, not competing with the code. Hide entirely on
   strikeouts (no batted ball).

5. **Out number got a chip.** A circled red number top-right (`r=5.5px`,
   0.9px stroke, no fill) — the traditional scorebook convention.
   Reads as a "1 out" / "2 outs" badge instead of floating debris.

## Components — Paper variant

### Card shell (`.sc-shell.sc-shell--paper`)

- Cream paper background (gradients above)
- 18px / 20px / 22px padding (top / sides / bottom)
- Body type: Georgia serif throughout the card
- Inner gap: 14px between header / line score / section header / batter grid

### Header (`.sc-head`)

- Flex row, space-between
- **Left:** game title (Playfair italic 800, navy) + subtitle (Georgia
  italic 400, pencil) showing inning + venue + date with a live dot
  (#e5484d, 6px, halo)
- **Right:** variant tag — 0.55rem letter-spaced "PAPER" in a red
  thin-bordered pill, Georgia caps

### Line score (`.ls`)

- Width 100%, border-collapse, font: Courier New mono 0.7rem
- Inning columns ~22px wide, R/H/E columns 26px wide
- Header inning numbers: 0.58rem, navy @ 0.7 opacity
- Cells: tabular numerals, 5px vertical padding
- R/H/E totals: navy 800-weight, faint-sand-tinted background
- Team-name column: Georgia 700, navy, left-aligned, 0.66rem
- Row separator: 1px solid faint sand

### Section header (`.sc-section-h`)

- "TEAM — BATTING" pattern (e.g. "YANKEES — BATTING")
- Georgia italic, 0.62rem, navy, letter-spacing 0.12em
- 1px solid faint sand bottom border
- 4px padding below

### Batter row (`.row`)

- CSS Grid: 110px name column + 9 equal inning columns
- 3px vertical padding
- Row separator: 1px dotted `rgba(199,184,150,0.7)` bottom border
- Name cell: order # (red 700) + name (Georgia 700 navy) + position
  (Georgia italic 400 pencil), baseline-aligned, 6px gap, 4px left pad

### Diamond cell (`.sc-cell`)

- 76×76px SVG inside the cell
- Below the diamond: 2px gap, then the foot caption (`b-s · #p`) in
  Courier mono 0.54rem pencil
- Inning-ending cells get a subtle 135° red diagonal stripe overlay on
  the cell background (see `artboard.css` for the gradient)

### Spray vector

The spray vector reuses the production geometry — direction (pull /
center / oppo) within the ±45° fair wedge, depth from
`hitData.coordinates` distance, fly balls/popups arced via Q-bezier,
grounders/line drives straight. The only changes from current are
**palette** (pencil mute instead of muted gray), **stroke width** (0.9px
instead of 1.2px), and **suppression on strikeouts**.

## Interactions & behaviour

No interaction changes from the current implementation. The visual
redesign is independent of:

- Open / close lifecycle (`openScorecardOverlay(gamePk)`,
  `closeScorecardOverlay()`)
- Live-refresh on `TIMING.LIVE_REFRESH_MS`
- Fetch / model construction (`buildModel(feed)`)
- Window exports + Escape-to-close

Everything in `src/overlay/scorecard.js` from `buildModel` upward stays
as-is. Only `diamondSVG()`, `renderInto()`, `renderLineScore()`,
`renderTeamTable()`, `renderPitchers()` and the supporting `.sc-*` CSS
need touching.

## Cell-data contract

The diamond renderer receives a `cell` object with the exact shape
produced by `buildModel()` today. Reference `fixture.js` for an example
record:

```js
{
  code: 'HR',          // string — '1B' / '2B' / '3B' / 'HR' / 'BB' / 'K' / 'ꓘ' / '6-3' / 'F8' / 'E5' / …
  hit: true,           // boolean — counted as a hit
  out: false,          // boolean — batter retired
  reached: 3,          // 0/1/2/3 — furthest base reached
  scored: true,        // boolean — run crossed the plate
  rbi: 3,              // integer — runs batted in (renders one red dot each)
  adv: '',             // 'SB' | 'WP' | 'PB' | 'BK' | 'DI' | 'E' | 'safe' — advancement reason
  outNum: 0,           // 0/1/2/3 — out count after this play (renders chip when >0)
  inningEnd: false,    // boolean — this play ended the half-inning (renders red diagonal)
  b: 1, s: 2, p: 5,    // balls / strikes / pitch count for the AB
  hc: { x: 60, y: 50 },// Gameday batted-ball landing coords (home ≈ 125.42, 198.27); null when none
  traj: 'fly_ball'     // 'fly_ball' | 'popup' | 'line_drive' | 'ground_ball' | ''
}
```

## Implementation checklist

1. **Drop in the new palette.** Add `--paper-cream`, `--ink-navy`,
   `--ink-red`, `--faint-sand`, `--pencil-mute` to `styles.css`. Either
   gate behind a `.sc-shell--paper` modifier (variant toggle) or
   replace the existing `.sc-*` palette outright.
2. **Replace `diamondSVG()`.** Use `diamond-paper.js` as the spec —
   same function signature, same input cell shape, new output SVG.
3. **Bump cell size.** Change `.sc-cell { width: 60px; height: 60px }`
   to `width: 80px; height: 80px` (the SVG is 76px; cell adds 2px
   padding each side). Update the 38px mini-diamond used in
   `renderCellStack` for batting-around to match the new proportions
   (~54px).
4. **Update typography.** Add the Playfair Display Google Font import.
   Switch `.sc-title` / `.sc-team-h` / `.sc-section-h` to Georgia
   italic + navy. Switch the line-score table to Courier New mono.
5. **Inning-ending diagonal background.** Add the 135° red diagonal
   gradient overlay rule on `.sc-cell.inning-end` (currently the diagonal
   is drawn inside the SVG; the cell-level overlay reads better at the
   new scale).
6. **Variant toggle (if shipping both).** Add a Settings row or a small
   pill in the scorecard header. Persist to `localStorage` under
   `scorecardVariant`. Apply by toggling `.sc-shell--paper` on
   `#scorecardCard`.

## Out of scope for this handoff

- Print stylesheet (a separate ask, but a natural follow-up since the
  Paper variant is print-ready by design)
- Per-inning LOB column (a feature request, not a visual fix)
- Mobile sticky-name column (visual treatment is unchanged; the
  layout fix is independent of the variant)

## Open the reference

```
open reference.html
```

Two artboards stacked:
1. **Full scorecard** — line score + 6-player batter grid with mixed
   outcomes (single, walk, HR, K, groundout, flyout — the last ending
   the inning). This is the production target.
2. **Cell hierarchy detail** — HR / K / groundout rendered large to
   show the scan-readability fix.
