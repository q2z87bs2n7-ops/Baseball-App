// Small fixture: top of 3rd inning, 4 PAs, mixed outcomes.
// Each cell mirrors what buildModel() in src/overlay/scorecard.js produces.
window.SC_FIXTURE = {
  away: 'YANKEES',
  home: 'METS',
  inn: 3,
  lineup: [
    { ord: 1, name: 'Volpe',     pos: 'SS' },
    { ord: 2, name: 'Soto',      pos: 'RF' },
    { ord: 3, name: 'Judge',     pos: 'CF' },
    { ord: 4, name: 'Stanton',   pos: 'DH' },
    { ord: 5, name: 'Chisholm',  pos: '2B' },
    { ord: 6, name: 'Wells',     pos: 'C'  },
  ],
  // cells[i] aligns to lineup[i]; null = no PA this inning.
  // hc coords are in MLB Gameday space (home ≈ 125.42, 198.27).
  cells: [
    { code:'1B',  hit:true,  out:false, reached:1, scored:true,  rbi:0, adv:'',   b:2, s:1, p:4, hc:{x:80,y:120},  traj:'line_drive' },
    { code:'BB',  hit:false, out:false, reached:1, scored:true,  rbi:0, adv:'',   b:4, s:2, p:7, hc:null },
    { code:'HR',  hit:true,  out:false, reached:3, scored:true,  rbi:3, adv:'',   b:1, s:2, p:5, hc:{x:60,y:50},   traj:'fly_ball' },
    { code:'ꓘ',  hit:false, out:true,  reached:0, scored:false, rbi:0, adv:'',   outNum:1, b:0, s:3, p:4 },
    { code:'6-3',hit:false, out:true,  reached:0, scored:false, rbi:0, adv:'',   outNum:2, b:1, s:1, p:3, hc:{x:140,y:170}, traj:'ground_ball' },
    { code:'F8', hit:false, out:true,  reached:0, scored:false, rbi:0, adv:'',   outNum:3, inningEnd:true, b:2, s:2, p:6, hc:{x:125,y:30}, traj:'fly_ball' },
  ]
};
